import { Router } from "express";
import multer from "multer";
import path from "path";

import {
  uploadDocument,
  listImports,
  getImportById,
} from "../controllers/import.controller.js";

const router = Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const baseName = path
      .basename(file.originalname, ext)
      .replace(/\s+/g, "_")
      .replace(/[^\w\-]/g, "");

    cb(null, `${Date.now()}-${baseName}${ext}`);
  },
});



const allowedMimeTypes = new Set([
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
  "text/csv",
  "application/xml",
  "text/xml",
]);

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    if (allowedMimeTypes.has(file.mimetype)) {
      return cb(null, true);
    }
    cb(new Error(`Type de fichier non supporté: ${file.mimetype}`));
  },
  limits: {
    fileSize: 15 * 1024 * 1024,
  },
});

router.post("/import/upload", upload.single("file"), uploadDocument);
router.get("/imports", listImports);
router.get("/imports/:id", getImportById);

export default router;