import {
  createImportedDocument,
  listImportedDocuments,
  getImportedDocumentById,
  updateImportedDocument,
} from "../storage/import.store.js";
import { dispatchBusinessDocument } from "../services/business-dispatch.service.js";
import { extractDocumentContent } from "../services/file-extractor.service.js";
import { extractInvoiceFieldsFromText } from "../services/invoice-parser.service.js";
import { inferInvoiceNatureHints } from "../services/invoice-nature.service.js";
import { classifyWithOpenAI } from "../services/openai.service.js";
import { resolveDestination } from "../services/dispatch.service.js";

console.log("LOADED import.controller.js VERSION NEW");

export async function uploadDocument(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({
        error: "Aucun fichier reçu",
      });
    }

    const extracted = await extractDocumentContent(
      req.file.path,
      req.file.mimetype,
      req.file.originalname
    );

    let structuredData = null;
    let natureHints = null;
    let classification = {
      label: null,
      confidence: null,
      invoiceNature: null,
      fields: {},
      provider: null,
      raw: null,
    };

    let destination = null;
    let status = "uploaded";

    if (extracted.kind === "error") {
      status = "extraction_failed";
    } else {
      structuredData = extractInvoiceFieldsFromText(extracted.text);

      natureHints = inferInvoiceNatureHints({
        extractedText: extracted.text,
        structuredData,
      });

      try {
        classification = await classifyWithOpenAI({
          fileName: req.file.originalname,
          mimeType: req.file.mimetype,
          extractedText: extracted.text,
          structuredData,
          natureHints,
          filePath: req.file.path,
          pageImages: extracted.pageImages || [],
        });

        destination = resolveDestination(
          classification.label,
          classification.confidence
        );

        status =
          destination === "a_valider" ? "manual_review" : "classified";
      } catch (classificationError) {
        console.error("OpenAI classification error:", classificationError);
        status = "classification_failed";
      }
    }

    const localNature = structuredData?.invoiceNature;
    const localNatureConfidence = natureHints?.confidence;

    if (
      localNature &&
      localNature !== "unknown" &&
      localNatureConfidence === "high"
    ) {
      classification.invoiceNature = localNature;
    }

    const detectedType =
      classification.label || structuredData?.documentType || null;

    const finalDocumentType =
      structuredData?.documentType || classification.label || null;

    const fileUrl = `/uploads/${req.file.filename}`;

    console.log("AVANT DB INSERT");

    const document = await createImportedDocument({
      fileName: req.file.filename,
      originalName: req.file.originalname,
      mimeType: req.file.mimetype,
      filePath: req.file.path,
      fileUrl,
      extractedText: extracted.text || null,
      extractionMethod: extracted.method || extracted.kind || null,
      documentType: finalDocumentType,
      invoiceNature: classification.invoiceNature || null,
      status,
      destination,
      classification: {
        label: classification.label,
        confidence: classification.confidence,
        invoiceNature: classification.invoiceNature,
        fields: classification.fields,
        provider: classification.provider,
      },
      structuredData,
    });

    console.log("APRES DB INSERT", document);
    console.log("EXTRACTION KIND:", extracted.kind);
    console.log("EXTRACTION METHOD:", extracted.method);
    console.log("EXTRACTION TEXT LENGTH:", extracted.text?.length || 0);
    console.log("EXTRACTION TEXT PREVIEW:", extracted.text?.slice(0, 300));
    console.log("PAGE IMAGES:", extracted.pageImages);

    const documentId = document?.id || document?._id?.toString();

    const businessInput = {
      ...document.toObject?.() ?? document,
      detectedType,
      invoiceNature: classification.invoiceNature,
      structuredData,
      extractedFields: classification.fields,
      fileUrl,
    };

    const businessResult = await dispatchBusinessDocument(businessInput);

    if (businessResult?.target && documentId) {
      const mappedDestination =
        businessResult.target === "review"
          ? "a_valider"
          : businessResult.target;

      await updateImportedDocument(documentId, {
        destination: mappedDestination,
      });
    }

    const refreshedDocument = documentId
      ? await getImportedDocumentById(documentId)
      : document;

    return res.status(201).json({
      success: true,
      message: "Fichier importé et traité",
      document: refreshedDocument,
      extraction: {
        kind: extracted.kind,
        preview: extracted.text ? extracted.text.substring(0, 300) : null,
        error: extracted.error || null,
      },
      business: businessResult,
      structuredData,
      natureHints,
      classification: {
        label: classification.label,
        confidence: classification.confidence,
        invoiceNature: classification.invoiceNature,
        fields: classification.fields,
        provider: classification.provider,
      },
      destination: refreshedDocument?.destination || destination,
    });
  } catch (error) {
    console.error("uploadDocument error:", error);
    return res.status(500).json({
      error: "Erreur pendant l'upload",
      details: String(error),
    });
  }
}

export async function listImports(req, res) {
  try {
    const documents = await listImportedDocuments();

    return res.json({
      success: true,
      count: documents.length,
      documents,
    });
  } catch (error) {
    console.error("listImports error:", error);
    return res.status(500).json({
      error: "Erreur pendant la récupération des imports",
      details: String(error),
    });
  }
}

export async function getImportById(req, res) {
  try {
    const { id } = req.params;
    const document = await getImportedDocumentById(id);

    if (!document) {
      return res.status(404).json({
        error: "Document introuvable",
      });
    }

    return res.json({
      success: true,
      document,
    });
  } catch (error) {
    console.error("getImportById error:", error);
    return res.status(500).json({
      error: "Erreur pendant la récupération du document",
      details: String(error),
    });
  }
}